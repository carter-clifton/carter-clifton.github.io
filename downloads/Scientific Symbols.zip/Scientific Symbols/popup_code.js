document.getElementById("main_iframe").src = "main_page.html";
let home_button = document.getElementById("toggle_home");
let math_button = document.getElementById("toggle_math");
let custom_button = document.getElementById("toggle_custom");
home_button.addEventListener("click", function() {switch_pages("home", pageShown)});
math_button.addEventListener("click", function() {switch_pages("math", pageShown)});
custom_button.addEventListener("click", function() {switch_pages("custom", pageShown)});

let pageShown = "home";
home_button.setAttribute("class", "main_button menu_button selected_page");

function switch_pages(targetPage, currentPage) {
    if (targetPage == currentPage) {
        return;
    } else {
        switch (targetPage) {
            case "home":
                document.getElementById("main_iframe").src = "main_page.html";
                pageShown = "home";
                home_button.setAttribute("class", "main_button menu_button selected_page");
                math_button.setAttribute("class", "main_button menu_button");
                custom_button.setAttribute("class", "main_button menu_button");
                break;
            case "math":
                document.getElementById("main_iframe").src = "math_page.html";
                pageShown = "math";
                math_button.setAttribute("class", "main_button menu_button selected_page");
                home_button.setAttribute("class", "main_button menu_button");
                custom_button.setAttribute("class", "main_button menu_button");
                break;
            case "custom":
                document.getElementById("main_iframe").src = "custom_page.html";
                pageShown = "custom";
                custom_button.setAttribute("class", "main_button menu_button selected_page");
                math_button.setAttribute("class", "main_button menu_button");
                home_button.setAttribute("class", "main_button menu_button");
                break;
            default:
                break;
        }
    }
}

function switch_page() {
    if (main_shown == true) {
        document.getElementById("main_iframe").src = "main_page.html";
        main_shown = false;
    } else {
        document.getElementById("main_iframe").src = "math_page.html";
        main_shown = true;
    }
}
