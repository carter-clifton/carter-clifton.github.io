document.getElementById("add_symbol").addEventListener("click", add_symbol);
document.getElementById("delete_custom").addEventListener("click", delete_custom);
document.getElementById("clear_custom").addEventListener("click", clear_custom);

load_symbols();
let delete_mode = false;

function delete_custom() {
    if (delete_mode == false) {
        document.getElementById("delete_custom").setAttribute("class", "main_button delete_on menu_button");
        delete_mode = true;
    } else {
        document.getElementById("delete_custom").setAttribute("class", "main_button menu_button");
        delete_mode = false;
    }
}

function clear_custom() {
    if (confirm("ARE YOU SURE YOU WANT TO CLEAR ALL OF YOUR CUSTOM BUTTONS? THIS CANNOT BE UNDONE!") == true) {
        chrome.storage.local.set({"buttons" : []}, function() {});
        document.getElementById("custom_symbol_container").innerHTML = '';
        displayEmptyMessage();
    }
}

function add_symbol() {
    var t = document.getElementById("custom_symbol_entry").value;
    var button = document.createElement("BUTTON");
    var name = document.createTextNode(t);
    button.appendChild(name);
    button.setAttribute("class", "symbol main_button new_button"); 
    button.onclick = function(){copyFunction(t, this)};
    document.getElementById("custom_symbol_container").appendChild(button);
    chrome.storage.local.get(["buttons"], function(button_array) {
        array = button_array["buttons"];
        array.push(t);
        chrome.storage.local.set({"buttons" : array}, function() {});
    })
    removeEmptyMessage();
}

function linkListener() {
    if (delete_mode == false) {
        copyFunction(this.symbol, null);
    } else {
        symbol_to_remove = this.symbol;
        this.remove(); 
        delete_mode = false;
        document.getElementById("delete_custom").setAttribute("class", "main_button");
        chrome.storage.local.get(["buttons"], function(button_array) {
            array = button_array["buttons"];
            let new_array = [];
            for (var i = 0;  i < array.length; i++) {
                if (array[i] == symbol_to_remove) {
                }  else {
                    new_array.push(array[i]);
                }
            }
            chrome.storage.local.set({"buttons" : new_array}, function() {});
        })
    }
}

function load_symbols() {
    chrome.storage.local.get(["buttons"], function(button_array) {
        array = button_array["buttons"];
        if (array == undefined) {
            chrome.storage.local.set({"buttons" : []}, function() {});
            load_symbols();
        } else {
            if (array.length == 0) {
                displayEmptyMessage();
            } else {
                for (var i = 0; i < array.length; i++) {
                    var button = document.createElement("BUTTON");
                    var name = document.createTextNode(array[i]);
                    button.appendChild(name);
                    button.setAttribute("class", "symbol main_button");
                    button.setAttribute("id", array[i]);
                    button.symbol = array[i];
                    button.onclick = linkListener;
                    document.getElementById("custom_symbol_container").appendChild(button);
                }
            }
        }
    })
}

function retrieve_symbols() {
    chrome.storage.local.get(["buttons"], function(button_array) {
        return button_array["buttons"];
    })
}

function copyFunction(param, button) {
    if ((button != null) && (button.classList.contains("new_button")) && (delete_mode == true)) {
        chrome.storage.local.get(["buttons"], function(button_array) {
            array = button_array["buttons"];
            symbol_to_remove = button.innerHTML;
            let new_array = [];
            for (var i = 0;  i < array.length; i++) {
                if (array[i] == symbol_to_remove) {
                }  else {
                    new_array.push(array[i]);
                }
            }
            chrome.storage.local.set({"buttons" : new_array}, function() {});
        })
        button.remove();
        delete_mode = false;
        document.getElementById("delete_custom").setAttribute("class", "main_button");
        if (document.getElementById("custom_symbol_container").querySelectorAll('button').length == 0) {
            displayEmptyMessage();
        }
    } else {
        navigator.clipboard.writeText(param);
    }
}

function displayEmptyMessage() {
    label = document.createElement("label");
    label.innerHTML = "No custom symbols yet :(";
    label.setAttribute("class", "no_symbols_text");
    document.getElementById("custom_symbol_container").appendChild(label);
}

function removeEmptyMessage() {
    const text = document.querySelectorAll('.no_symbols_text')
    for (const el of text) {
    el.parentNode.removeChild(el);
    }
}