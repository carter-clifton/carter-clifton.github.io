//window.onload = function() {
//    var iframe = document.getElementById('main_iframe');
//}

document.getElementById("degree").addEventListener("click", function() { copyFunction("°") });
document.getElementById("per_thousand").addEventListener("click", function() {copyFunction("‰")});
document.getElementById("eszett").addEventListener("click", function() {copyFunction("ß")});
document.getElementById("reversible").addEventListener("click", function() {copyFunction("⇌")});
document.getElementById("superscript").addEventListener("click", superscript);
document.getElementById("subscript").addEventListener("click", subscript);
document.getElementById("greek").addEventListener("click", greek);

document.getElementById("help").addEventListener("click", help);

function greek() {
    var t = document.getElementById("greek_entry").value;
    trimmedText = t.trim();
    if (trimmedText in greekLetters) {
        greekLetter = greekLetters[trimmedText];
        copyFunction(greekLetter);
    } else {
        copyFunction("?")
    }
}

function superscript() {
    var t = document.getElementById("text_entry").value;
    let finalString = '';
    for (let i = 0; i < t.length; i++) {
        char = t[i];
        if (!(char in superscriptText)) {
            finalString += "?"
        } else {
            finalString += superscriptText[char];
        }
    }
    copyFunction(finalString);
}

function subscript() {
    var t = document.getElementById("text_entry").value;
    let finalString = ''
    for (let i = 0; i < t.length; i++) {
        char = t[i];
        if (!(char in subscriptText)) {
            finalString += "?"
        } else {
            finalString += subscriptText[char];
        }
    }
    copyFunction(finalString);
}

function copyFunction(param) {
    navigator.clipboard.writeText(param);
}

function help() {
    alert('Pressing a button will copy the symbol to your clipboard!\nTo use the superscript / subscript text, type any string of characters into the textbox and press the corresponding button.\n*NOTE* Some characters do not have superscript or subscript forms (Like Q).\nTo get a greek letter, type the name of the letter into the textbox and press the button. ("delta" for δ and "DELTA" for Δ)'); 
}

const superscriptText = {
    1 : "¹",
    2 : "²",
    3 : "³",
    4 : "⁴",
    5 : "⁵",
    6 : "⁶",
    7 : "⁷",
    8 : "⁸",
    9 : "⁹",
    0 : "⁰",
    a : "ᵃ",
    b : "ᵇ",
    c : "ᶜ",
    d : "ᵈ",
    e : "ᵉ",
    f : "ᶠ",
    g : "ᵍ",
    h : "ʰ",
    j : "ʲ",
    k : "ᵏ",
    l : "ˡ",
    m : "ᵐ",
    n : "ⁿ",
    o : "ᵒ",
    p : "ᵖ",
    q : "ᑫ",
    r : "ʳ",
    s : "ˢ",
    t : "ᵗ",
    u : "ᵘ",
    v : "ᵛ",
    w : "ʷ",
    x : "ˣ",
    y : "ʸ",
    z : "ᶻ",
    A : "ᴬ",
    B : "ᴮ",
    C : "ᶜ",
    D : "ᴰ",
    E : "ᴱ",
    F : "ᶠ",
    G : "ᴳ",
    H : "ᴴ",
    I : "ᴵ",
    J : "ᴶ",
    K : "ᴷ",
    L : "ᴸ",
    M : "ᴹ",
    N : "ᴺ",
    O : "ᴼ",
    P : "ᴾ",
    Q : "Q",
    R : "ᴿ",
    S : "ˢ",
    T : "ᵀ",
    U : "ᵁ",
    V : "ⱽ",
    W : "ᵂ",
    X : "ˣ",
    Y : "ʸ",
    Z : "ᶻ",
    "+" : "⁺",
    "-" : "⁻",
    " " : " "
}

const subscriptText = {
    1 : "₁",
    2 : "₂",
    3 : "₃",
    4 : "₄",
    5 : "₅",
    6 : "₆",
    7 : "₇",
    8 : "₈",
    9 : "₉",
    0 : "₀",
    a : "ₐ",
    b : "ᵦ",
    c : "𝒸",
    d : "𝒹",
    e : "ₑ",
    f : "𝒻",
    g : "𝓰",
    h : "ₕ",
    j : "ⱼ",
    k : "ₖ",
    l : "ₗ",
    m : "ₘ",
    n : "ₙ",
    o : "ₒ",
    p : "ₚ",
    q : "ᵩ",
    r : "ᵣ",
    s : "ₛ",
    t : "ₜ",
    u : "ᵤ",
    v : "ᵥ",
    w : "𝓌",
    x : "ₓ",
    y : "ᵧ",
    z : "𝓏",
    A : "ₐ",
    B : "B",
    C : "C",
    D : "D",
    E : "ₑ",
    F : "F",
    G : "G",
    H : "ₕ",
    I : "ᵢ",
    J : "ⱼ",
    K : "ₖ",
    L : "ₗ",
    M : "ₘ",
    N : "ₙ",
    O : "ₒ",
    P : "ₚ",
    Q : "Q",
    R : "ᵣ",
    S : "ₛ",
    T : "ₜ",
    U : "ᵤ",
    V : "ᵥ",
    W : "W",
    X : "ₓ",
    Y : "Y",
    Z : "Z",
    "+" : "₊",
    "-" : "₋",
    " " : " "
}

const greekLetters = {
"alpha" : "α",
"ALPHA" : "Α",
"beta" : "β",
"BETA" : "Β",
"gamma" : "γ",
"GAMMA" : "Γ",
"delta" : "δ",
"DELTA" : "Δ",
"epsilon" : "ε",
"EPSILON" : "Ε",
"zeta" : "ζ",
"ZETA" : "Ζ",
"eta" : "η",
"ETA" : "Η",
"theta" : "η",
"THETA" : "Θ",
"iota" : "ι",
"IOTA" : "Ι",
"kappa" : "κ",
"KAPPA" : "Κ",
"lambda" : "λ",
"LAMBDA" : "Λ",
"mu" : "μ",
"MU" : "Μ",
"nu" : "ν",
"NU" : "Ν",
"xi" : "ξ",
"XI" : "Ξ",
"omicron" : "ο",
"OMICRON" : "Ο",
"pi" : "π",
"PI" : "Π",
"rho" : "ρ",
"RHO" : "Ρ",
"sigma" : "σ",
"sigma2" : "ς",
"SIGMA" : "Σ",
"tau" : "τ",
"TAU" : "Τ",
"upsilon" : "υ",
"UPSILON" : "Υ",
"phi" : "φ",
"PHI" : "Φ",
"chi" : "χ",
"CHI" : "Χ",
"psi" : "ψ",
"PSI" : "Ψ",
"omega" : "ω",
"OMEGA" : "Ω"
}