second_hand = document.getElementById("second_hand");
minute_hand = document.getElementById("minute_hand");
hour_hand = document.getElementById("hour_hand");

second_rotation = 180;
minute_rotation = 180;
hour_rotation = 180;

function tick() {
    second_rotation += 6;
    minute_rotation += 0.1;
    hour_rotation += 1 / 120;

    second_hand.style.rotate = second_rotation + "deg";
    minute_hand.style.rotate = minute_rotation + "deg";
    hour_hand.style.rotate = hour_rotation + "deg";
}

var intervalId = window.setInterval(function(){
    tick();
}, 1);